package com.example.mp3player

import android.media.MediaPlayer
import android.media.MediaPlayer.OnCompletionListener
import android.os.Bundle
import android.os.Handler
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private var songs: MutableList<Int> = mutableListOf(
        R.raw.witcher_gwent,
        R.raw.witcher_nightingale,
        R.raw.dream_catcher,
        R.raw.nevermind,
        R.raw.old_town_road
    )
    private var player: MediaPlayer? = null
    var currentSongIndex = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        songsController()
    }

    private fun setPlay()
    {
        play.setOnClickListener {
            if (player == null) {
                player = MediaPlayer.create(this, songs[currentSongIndex])
                player?.setOnCompletionListener(OnCompletionListener { mPlayer ->
                    reset()
                    currentSongIndex++
                    currentSongIndex %= songs.size
                    player = MediaPlayer.create(this, songs[currentSongIndex])
                    initializeSeekBar()
                    player?.start()
                })
                initializeSeekBar()
            }
            player?.start()
        }
    }

    private fun setPause()
    {
        pause.setOnClickListener {
            if (player != null) player?.pause()
        }
    }

    private fun setStop()
    {
        stop.setOnClickListener {
            if (player != null) {
                player?.stop()
                player?.reset()
                player?.release()
                player = null
            }
        }
    }

    private fun setNext()
    {
        next.setOnClickListener {
            if (player != null) {
                reset()
                currentSongIndex++
                currentSongIndex %= songs.size
                player = MediaPlayer.create(this, songs[currentSongIndex])
                initializeSeekBar()
                player?.start()
            }
        }
    }

    private fun setPrevious()
    {
        previous.setOnClickListener {
            if (player != null) {
                reset()
                currentSongIndex--
                if (currentSongIndex < 0) currentSongIndex = songs.size-1
                player = MediaPlayer.create(this, songs[currentSongIndex])
                initializeSeekBar()
                player?.start()
            }
        }
    }

    private fun setForward()
    {
        forward.setOnClickListener {
            if (player != null) {
                val newTime = player?.currentPosition!!.plus(10000)
                player?.seekTo(newTime)
            }
        }
    }

    private fun setBack()
    {
        back.setOnClickListener {
            if (player != null) {
                val newTime = player?.currentPosition!!.minus(10000)
                player?.seekTo(newTime)
            }
        }
    }


    private fun songsController() {

        setPlay()
        setPause()
        setStop()
        setNext()
        setPrevious()
        setForward()
        setBack()
        seekbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) player?.seekTo(progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
            }
        })
    }

    private fun initializeSeekBar() {
        seekbar.max = player!!.duration

        val handler = Handler()
        handler.postDelayed(object : Runnable {
            override fun run() {
                try {
                    seekbar.progress = player!!.currentPosition
                    handler.postDelayed(this, 1000)
                } catch (e: Exception) {
                    seekbar.progress = 0
                }
            }
        }, 0)
    }

    private fun reset(){
        if(player != null){
                player?.stop()
                player?.reset()
                player?.release()
                player = null
                seekbar.progress = 0
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        reset()
    }

    override fun onStop() {
        super.onStop()
        reset()
    }
}